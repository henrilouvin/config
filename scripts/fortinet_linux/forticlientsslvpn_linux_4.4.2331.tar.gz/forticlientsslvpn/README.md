# INSTALL PROCEDURE

## Untar
```
tar xvf forticlientsslvpn_linux_4.4.2331.tar.gz
```

## Usage
```
cd forticlientsslvpn/
./fortinet
```
* (_first use only_) Click 'Ok'
* (_first use only_) Click 'Agree'
* (_first use only_) Enter sudo password
* Click 'Cancel' to close warning pop-up
* Fill the form:
```
    Server: mobietendu-im.cea.fr:443
    User: $username_intra
    Password: $tamagotchi
    Certificate: 
    Password:
```

